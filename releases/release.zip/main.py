from pynput import mouse, keyboard
from pynput.mouse import Button
import time
import threading
import ctypes, os
from modules.readjson import read_json as rjv
from flask import Flask, render_template, jsonify, request
import  requests, zipfile



import json

CONFIG_DIR = "configuration"
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def save_config(filename="config.json"):
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)
    data = {
        "x_val": x_val,
        "y_val": y_val,
        "speed": speed,
        "hipfire_x": hipfire_x,
        "hipfire_y": hipfire_y,
        "hipfire_speed": hipfire_speed,
        "hipfire_mode": hipfire_mode,
        "toggle_key": toggle_key,
        "reset_button": reset_button,
    }
    with open(os.path.join(CONFIG_DIR, filename), "w") as f:
        json.dump(data, f, indent=4)
    return data

def load_config(data=None, filename="config.json"):
    global x_val, y_val, speed, hipfire_x, hipfire_y, hipfire_speed, hipfire_mode, toggle_key, reset_button
    if data:
        cfg = data
    else:
        with open(os.path.join(CONFIG_DIR, filename), "r") as f:
            cfg = json.load(f)

    x_val = float(cfg.get("x_val", 0))
    y_val = float(cfg.get("y_val", 0))
    speed = float(cfg.get("speed", 0.02))
    hipfire_x = float(cfg.get("hipfire_x", 0))
    hipfire_y = float(cfg.get("hipfire_y", 0))
    hipfire_speed = float(cfg.get("hipfire_speed", 0.02))
    hipfire_mode = bool(cfg.get("hipfire_mode", False))
    toggle_key = cfg.get("toggle_key", "p")
    reset_button = cfg.get("reset_button", "h")

    return cfg



CURRENT_VERSION = "1.0.3"


VERSION_URL = "https://vacgtm.github.io/releases/version.json"

def check_for_update():
    r = requests.get(VERSION_URL)
    data = r.json()

    latest_version = data["version"]
    download_url = data["download_url"]

    if latest_version != CURRENT_VERSION:
        print(f"Update found: {latest_version} (current {CURRENT_VERSION})")
        download_update(download_url)
    else:
        print("No update available.")

def download_update(url):
    print("Downloading update...")
    r = requests.get(url, stream=True)
    r.raise_for_status()

    with open("update.zip", "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            f.write(chunk)

    print("Extracting update...")
    with zipfile.ZipFile("update.zip", "r") as zip_ref:
        zip_ref.extractall(".")

    print("Cleaning up...")
    os.remove("update.zip")

    print("✅ Update installed successfully. Exiting to apply changes...")
    time.sleep(3)
    os._exit(0)

check_for_update()

mouse_controller = mouse.Controller()
is_pressed = False
is_left_pressed = False
is_right_pressed = False

x_val = 0
y_val = 0
speed = 0
toggle_key = "p"
reset_button = "h"
hipfire_mode = False
hipfire_x = 0
hipfire_y = 0
hipfire_speed = 0

toggled = False
running = True

def move_mouse(dx, dy):
    ctypes.windll.user32.mouse_event(0x0001, int(dx), int(dy), 0, 0)

def recoil_code():
    global is_pressed, toggled, running, hipfire_mode, is_left_pressed, hipfire_x, hipfire_y, hipfire_speed
    while running:
        if toggled:
            if hipfire_mode:
                if is_left_pressed and not is_right_pressed:
                    move_mouse(hipfire_x, hipfire_y)
                    time.sleep(hipfire_speed)
                    continue
            if is_pressed:
                move_mouse(x_val, y_val)
                time.sleep(speed)
                continue
        time.sleep(0.01)

def on_click(x, y, button, pressed):
    global is_left_pressed, is_right_pressed, is_pressed
    if button == Button.left:
        is_left_pressed = pressed
    elif button == Button.right:
        is_right_pressed = pressed
    is_pressed = is_left_pressed and is_right_pressed

def on_press(key):
    global toggled
    try:
        if key == keyboard.KeyCode.from_char(toggle_key):
            toggled = not toggled
            print("toggled" if toggled else "untoggled")
        elif key == keyboard.KeyCode.from_char(reset_button):
            return init()
    except AttributeError:
        pass

def run_all(pre):
    global x_val, y_val, speed, toggled, hipfire_x, hipfire_y, hipfire_mode, hipfire_speed
    if pre.lower() == "g36c":
        x_val = 0.999; y_val = 6.9; speed = 0.025; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "mp7":
        x_val = 0.05; y_val = 7.4; speed = 0.02; hipfire_x = 0.05; hipfire_y = 8; hipfire_mode=True;hipfire_speed=0.045
    elif pre.lower() == "smg12":
        x_val = 3.5; y_val = 23; speed = 0.047; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "mp5":
        x_val = 0.05; y_val = 11; speed = 0.05; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "ak12":
        x_val = 0.0001; y_val = 7.1; speed = 0.02; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "f2":
        x_val = -1.75; y_val = 21.3; speed = 0.048; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "9x919vsn":
        x_val = -1.0612; y_val = 12.551; speed = 0.048; hipfire_x = 0.05; hipfire_y = 8; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "mp5k":
        x_val = 0.05; y_val = 13.8776; speed = 0.05; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "uzk50gi":
        x_val = 0.05; y_val = 13.0612; speed = 0.05; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "vector45acp":
        x_val = 0.0204; y_val = 17.7551; speed = 0.05; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "r4c":
        x_val = -1.7755; y_val = 25.9184; speed = 0.048; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "smg11":
        x_val = 2.7959; y_val = 21.4286; speed = 0.047; hipfire_x = 0.05; hipfire_y = 5.4; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "m4":
        x_val = -1.4694; y_val = 20; speed = 0.047; hipfire_x = 0.05; hipfire_y = 8; hipfire_mode=False;hipfire_speed=0.045
    elif pre.lower() == "custom":
        x_val = rjv("configuration/config.json", "x_val")
        y_val = rjv("configuration/config.json", "y_val")
        speed = rjv("configuration/config.json", "speed")
    os.system("cls")
    print(f"loaded {pre}")

def init():
    global toggle_key, reset_button
    os.system("cls")
    print("-- r6 recoil compensator --")
    toggle_key = rjv("configuration/config.json", "toggle_key")
    reset_button = rjv("configuration/config.json", "reset_button")
    print(f"open web browser and go to http://localhost:5000")
    os.system("start http://localhost:5000")

threading.Thread(target=recoil_code, daemon=True).start()

mouse_listener = mouse.Listener(on_click=on_click)
keyboard_listener = keyboard.Listener(on_press=on_press)
mouse_listener.start()
keyboard_listener.start()

app = Flask(__name__)

@app.route('/')
def index():
    return open("index.html").read()

@app.route('/toggle')
def toggle():
    global toggled
    toggled = not toggled
    return jsonify(state=toggled)

@app.route('/status')
def status():
    return jsonify(state=toggled, hipfire=hipfire_mode)

@app.route("/preset/<name>")
def load_preset(name):
    run_all(name)
    return jsonify({
        "preset": name,
        "x": x_val,
        "y": y_val,
        "speed": speed,
        "hipfire": hipfire_mode,
        "hipfire_x": hipfire_x,
        "hipfire_y": hipfire_y,
        "hipfire_speed": hipfire_speed
    })

@app.route('/set', methods=['POST'])
def set_values():
    global x_val, y_val, speed
    data = request.get_json(force=True)
    if "xval" in data: x_val = float(data["xval"])
    if "yval" in data: y_val = float(data["yval"])
    if "speed" in data: speed = float(data["speed"])
    return jsonify(status="updated", x=x_val, y=y_val, speed=speed)

@app.route("/hipfire", methods=["POST"])
def set_hipfire():
    global hipfire_mode
    data = request.get_json(force=True)
    hipfire_mode = bool(data.get("hipfire", False))
    return jsonify(hipfire=hipfire_mode)


@app.route("/save_config", methods=["POST"])
def save_config():
    data = request.json
    gun = data["gun"]
    name = data.get("name", "default")
    folder = os.path.join(CONFIG_DIR, gun)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"{name}.json")
    # Replace this with your actual config structure
    config = {"x":0.1,"y":0.2,"speed":0.01}
    with open(path, "w") as f:
        json.dump(config, f, indent=2)
    return jsonify({"status":"saved","config":config})

@app.route("/load_config", methods=["POST"])
def load_config():
    data = request.json
    gun = data["gun"]
    name = data.get("name", "default")
    path = os.path.join(CONFIG_DIR, gun, f"{name}.json")
    if os.path.exists(path):
        with open(path) as f:
            config = json.load(f)
        return jsonify({"status":"loaded","config":config})
    return jsonify({"status":"not_found"})


@app.route("/list_configs", methods=["POST"])
def list_configs():
    data = request.json
    gun = data["gun"]
    folder = os.path.join(CONFIG_DIR, gun)
    if not os.path.exists(folder):
        return jsonify({"configs":[]})
    files = [os.path.splitext(f)[0] for f in os.listdir(folder) if f.endswith(".json")]
    return jsonify({"configs": files})


@app.route("/set_hipfire", methods=["POST"])
def set_hipfire_values():
    global hipfire_x, hipfire_y, hipfire_speed
    data = request.get_json(force=True)
    if "hipfire_x" in data: hipfire_x = float(data["hipfire_x"])
    if "hipfire_y" in data: hipfire_y = float(data["hipfire_y"])
    if "hipfire_speed" in data: hipfire_speed = float(data["hipfire_speed"])
    return jsonify(
        status="updated",
        hipfire_x=hipfire_x,
        hipfire_y=hipfire_y,
        hipfire_speed=hipfire_speed,
    )


def start_web():
    app.run(host="0.0.0.0", port=5000)

threading.Thread(target=start_web, daemon=True).start()

init()
mouse_listener.join()
keyboard_listener.join()
